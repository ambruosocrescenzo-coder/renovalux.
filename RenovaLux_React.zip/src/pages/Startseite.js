import React from 'react';
function Startseite() {
  return (
    <section>
      <h2>Willkommen bei RenovaLux GmbH</h2>
      <p>Ankauf, Renovation und Verkauf von Immobilien in der ganzen Schweiz.</p>
      <button>Kontaktieren Sie uns</button>
    </section>
  );
}
export default Startseite;