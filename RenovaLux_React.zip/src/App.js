import React from 'react';
import { Outlet, Link } from 'react-router-dom';
import './App.css';

function App() {
  return (
    <div>
      <header className='header'>
        <h1>RenovaLux GmbH</h1>
        <nav>
          <Link to='/'>Startseite</Link>
          <Link to='/team'>Team</Link>
          <Link to='/dienstleistungen'>Dienstleistungen</Link>
          <Link to='/kontakt'>Kontakt</Link>
        </nav>
      </header>
      <main>
        <Outlet />
      </main>
      <footer>
        <p>© 2025 RenovaLux GmbH - Schweiz</p>
      </footer>
    </div>
  );
}

export default App;