import React from 'react';
function Team() {
  const mitglieder = ['Crescenzo Ambruoso', 'David Jenni', 'Santo Borrello'];
  return (
    <section>
      <h2>Unser Team</h2>
      <ul>
        {mitglieder.map((mitglied, idx) => (
          <li key={idx}>{mitglied}</li>
        ))}
      </ul>
    </section>
  );
}
export default Team;