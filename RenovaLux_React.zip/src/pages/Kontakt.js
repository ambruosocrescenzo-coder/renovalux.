import React, { useState } from 'react';
function Kontakt() {
  const [form, setForm] = useState({ name: '', email: '', nachricht: '' });
  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });
  const handleSubmit = e => {
    e.preventDefault();
    alert('Vielen Dank für Ihre Nachricht!');
    setForm({ name: '', email: '', nachricht: '' });
  };

  return (
    <section>
      <h2>Kontaktieren Sie uns</h2>
      <form onSubmit={handleSubmit}>
        <input name='name' value={form.name} onChange={handleChange} placeholder='Name' required />
        <input type='email' name='email' value={form.email} onChange={handleChange} placeholder='E-Mail' required />
        <textarea name='nachricht' value={form.nachricht} onChange={handleChange} placeholder='Nachricht' required />
        <button type='submit'>Absenden</button>
      </form>
    </section>
  );
}
export default Kontakt;