import React from 'react';
function Dienstleistungen() {
  return (
    <section>
      <h2>Unsere Dienstleistungen</h2>
      <ul>
        <li>Ankauf gebrauchter Immobilien</li>
        <li>Renovation</li>
        <li>Verkauf</li>
      </ul>
    </section>
  );
}
export default Dienstleistungen;