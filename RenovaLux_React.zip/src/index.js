import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './index.css';
import App from './App';
import Startseite from './pages/Startseite';
import Team from './pages/Team';
import Dienstleistungen from './pages/Dienstleistungen';
import Kontakt from './pages/Kontakt';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Router>
      <Routes>
        <Route path='/' element={<App />}>
          <Route index element={<Startseite />} />
          <Route path='team' element={<Team />} />
          <Route path='dienstleistungen' element={<Dienstleistungen />} />
          <Route path='kontakt' element={<Kontakt />} />
        </Route>
      </Routes>
    </Router>
  </React.StrictMode>
);